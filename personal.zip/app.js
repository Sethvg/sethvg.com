var app = angular.module('app',['ui.bootstrap']);

app.controller('main',['$scope','$modal',function($scope,$modal){
    $scope.navMenu = [
        {text:'Home',partial:'home.html', selected:true},
        {text:'Work',partial:'work.html', selected:false},
        {text:'Projects',partial:'projects.html' , selected:false},
        {text:'Education',partial:'education.html',selected:false}
    ];



    $scope.setSelected = function(index){
        for(var a = 0; a < $scope.navMenu.length; a++){
            $scope.navMenu[a].selected = false;
        }
        $scope.navMenu[index].selected = true;
        $scope.selected = $scope.navMenu[index];
    };

    $scope.setSelected(0);

    $scope.images = [];

    function addImage(name,src){
        $scope.images.push({name:name,src:'assets/' + src})
    }

    addImage('Angular JS','angularjs.png');
    addImage('NodeJs','nodejs.png');
    addImage('Bootstrap','bootstrap.jpg');
    addImage('Ruby (+Rails)' , 'ror.png');
    addImage('Git' , 'git_logo.png');
    addImage('C++','cpp.png');
    addImage("Java",'Java.png');
    addImage('Grunt' , 'grunt.png');
    addImage('Javascript' , 'javascript.png');

    $scope.about = [];

    function addAbout(key,value){
        $scope.about.push({key:key,value:value});
    }

    addAbout('Name','Seth Van Grinsven');
    var date = new Date();
    var diff = date.getFullYear() - 1990;
    if(date.getMonth() == 0 || (date.getMonth() == 1 && date.getDate() < 8)) diff -= 1;
    addAbout('Age',String(diff));
    addAbout('Location', 'Rancho Cordova');
    addAbout('Current Job', 'Developer Intern');
    addAbout('Graduation Date', 'Dec 2015');
    addAbout('Favorite Language',"AgularJS");

    $scope.first = false;
    $scope.profs = [];

    function addProf(str,skill){
        var a = 0;
        var found = false;
        for(a = 0; a < $scope.profs.length && !found; a++){
            if($scope.profs[a].skill <= skill) found = true;
        }
        if(found) a--;
        $scope.profs.splice(a,0,{name:str,skill:skill});
    }


    addProf('Ruby',6.5);
    addProf('Android',6);
    addProf('C#',4);
    addProf('Ios',2);
    addProf('AngularJS', 9.5);
    addProf('C++', 9);
    addProf('Javascript',9);
    addProf('Java',8);

    $scope.tools = [];
    function addTool(str, skill){
        var a = 0;
        var found = false;
        for(a = 0; a < $scope.tools.length && !found; a++){
            if($scope.tools[a].skill <= skill) found = true;
        }
        if(found) a--;
     $scope.tools.splice(a,0,{name:str,skill:skill});
    }

    addTool('Grunt',9.5);
    addTool('Git',9.5);

    addTool('IntelliJ Ide',10);

    addTool('Bower',9);
    addTool('Jenkins',8);
    addTool('Npm',8);
    addTool('Maven',5);

    $scope.test ={};
    $scope.addTool = function(na,sk){
        if(!$scope.first)$scope.clear();        if(angular.isUndefined(sk) || angular.isUndefined(na) || na == '' || sk == 0) return;
        addTool(na,parseInt(sk));
        $scope.first = true;

    };

    $scope.clear = function(){
        $scope.tools = [];
        $scope.profs = [];
    }

    $scope.addLanguage = function(na ,sk){
        if(!$scope.first)$scope.clear();
        if(angular.isUndefined(sk) || angular.isUndefined(na) || na == '' || sk == 0) return;
        addProf(na,parseInt(sk));
        $scope.first = true;

    };

    $scope.open = function()
    {
        var modalInstance = $modal.open({
            animation: $scope.animationsEnabled,
            templateUrl: 'views/modal.html',
            size: 'modal-sm'


        });
    };












}]);