Controls

LR arrows - Moves ship in that direction
 *Stops ship if moving in oposite direction
 *IE: Moving left, hit right arrow, stops.
 *hit right again, moves right.


Mouse click - Fires missle at click location from tip of ship.